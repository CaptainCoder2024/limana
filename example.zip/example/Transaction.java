package org.example;

public class Transaction {
}
