package org.example;

public class Createinterface {

}
